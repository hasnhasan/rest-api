<?php
    $plugin_path = dirname(__FILE__) . "/app";
    require("restphp/query.php");
?>