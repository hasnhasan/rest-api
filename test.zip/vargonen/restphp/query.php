<?php
require('init.php');
use restphp\Request;
use restphp\ApplicationController;

$request = new Request(array('restful' => true, 'url_prefix' => 'api/'));
if (is_null($request->controller)) {
    http_response_code(404);
    exit;
}


$controller_file = "${plugin_path}/controllers/" . $request->controller . '.php';
$model_file = "${plugin_path}/models/" . $request->controller . '.php';
if (file_exists($model_file)) {
    require_once($model_file);
}
if (file_exists($controller_file)) {
    require_once($controller_file);
    $controller_name = ucfirst($request->controller.'Controller');
    $controller = new $controller_name($request->controller);
} else {
    $controller = new ApplicationController($request->controller);
}


echo $controller->dispatch($request);
?>
