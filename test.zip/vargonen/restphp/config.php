<?php
    $mysql_hostname = "localhost";
    $mysql_username = "root";
    $mysql_password = "1";
    $mysql_database = "vargonen";
?>